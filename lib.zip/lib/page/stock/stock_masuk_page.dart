import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:blackmarket/model/stock/stock_masuk_model.dart';
import 'package:blackmarket/service/stock/stock_masuk_service.dart';
import 'package:blackmarket/page/stock/stock_masuk_form_page.dart';

class StockMasukPage extends StatefulWidget {
  @override
  _StockMasukPageState createState() => _StockMasukPageState();
}

class _StockMasukPageState extends State<StockMasukPage> {
  late StockMasukService _stockMasukService;
  late Box<StockMasuk> _stockMasukBox;
  late Stream<BoxEvent> _stockMasukBoxStream;

  @override
  void initState() {
    super.initState();
    _stockMasukBox = Hive.box<StockMasuk>('stockMasukBox');
    _stockMasukService = StockMasukService(_stockMasukBox);
    _stockMasukBoxStream = _stockMasukBox.watch().distinct();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Stok Masuk'),
      ),
      body: StreamBuilder<BoxEvent>(
        stream: _stockMasukBoxStream,
        builder: (context, snapshot) {
          if (!snapshot.hasData || snapshot.data == null) {
            return Center(
              child: Text('Tidak ada data stok masuk'),
            );
          }

          List<StockMasuk> stockMasukList = _stockMasukBox.values.toList();

          if (stockMasukList.isEmpty) {
            return Center(
              child: Text('Tidak ada data stok masuk'),
            );
          }

          return ListView.builder(
            itemCount: stockMasukList.length,
            itemBuilder: (context, index) {
              StockMasuk stockMasuk = stockMasukList[index];
              return ListTile(
                title: Text(stockMasuk.barang.nama),
                subtitle: Text(
                    'Jumlah: ${stockMasuk.jumlah}, Tanggal: ${stockMasuk.tanggalMasuk}'),
                trailing: IconButton(
                  icon: Icon(Icons.delete),
                  onPressed: () {
                    _stockMasukService.deleteStockMasuk(stockMasuk.id);
                  },
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          StockMasukFormPage(stockMasuk: stockMasuk),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => StockMasukFormPage(),
            ),
          );
        },
        child: Icon(Icons.add),
      ),
    );
  }
}
